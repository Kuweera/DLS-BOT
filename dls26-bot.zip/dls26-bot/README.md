# DLS Bot v1.1 — possession safety milestone

An on-device Android app (Kotlin) that plays DLS 26 fixtures against computer teams: menus, cutscenes,
the match, half-time and full-time adverts, and the rewards screen, then moves on to the next fixture.

## Build it from a phone (no Android Studio)
1. On github.com create a new repository ("Desktop site" in your browser helps).
2. Add file > Create new file. Name it `.github/workflows/build.yml` and paste in the contents of `build.yml`. Commit.
3. Add file > Upload files. Upload `dls26-bot.zip` itself (do not unzip it). Commit.
4. Open the Actions tab > "Build APK". Wait for the green tick (5 to 10 minutes) and download the `dls-bot-apk` file. Unzip it and install `app-debug.apk`.
5. If Android blocks the accessibility service: Settings > Apps > DLS Bot > top-right menu > "Allow restricted settings".
   Then enable DLS Bot under Accessibility.
6. If the build fails, open the failed run, copy the red error text and send it to Claude.

## First run
1. Open DLS Bot. In Settings choose which side you attack in the FIRST half (starts as Left).
2. Press 1 (enable accessibility), 2 (start screen capture), 3 (start bot), then switch to DLS.
3. Start from the line-up screen or the home screen. Watch the first match.
4. If the "Attacking" read-out in the app is wrong, press "Flip attacking direction now" and change the setting.
5. "Show what the bot sees right now" lists every template score for the current screen. Use it on the menu and in a match.

## What it handles
| Screen | Action |
|---|---|
| Home | taps the fixture card marked with the red "PLAY NOW" tag |
| Line-up | taps PLAY |
| Cutscenes, replays, substitutions | taps TAP TO SKIP |
| Half time | waits, flips the attacking direction, taps RESUME after the advert |
| Adverts / Google Play | waits, taps the skip arrow when it appears, presses Back if it opens Google Play |
| Full time | claims bonus rewards (optional), then CONTINUE |
| Defending | switches periodically and uses short PRESSURE taps (never slide-tackles) |
| Free kick near goal | legacy rule: shoots when the gloves/yards templates match; verify direction before use |
| Corner | legacy rule: lofted cross; verify direction before use |
| Goal kick, throw-in, other restarts | legacy short-pass rule |
| Open play with the ball | cautious carry only; timer-driven passes/shots disabled until player/ball/goal vision exists |

## How the detection was checked
All detection logic was replayed on your 80 screenshots: 77 of 80 screens were classified as expected;
the 3 "misses" were two Game-settings screens and the black loading screen, now handled. Attack vs defend
(kick labels vs PRESSURE / SWITCH PLAYER) separated perfectly. The Android code itself has not been compiled
or run on a phone yet.

## v1.1 safety changes
- Possession is now three-state: OURS, OPPONENT, or UNKNOWN. Ambiguous button-label frames cause the bot to wait instead of assuming it has possession.
- Defensive pressure is a short tap rather than a 900 ms hold, reducing uncontrolled pressure input.
- Timer-driven open-play passes and shots have been disabled. The bot carries the ball briefly instead of blindly kicking without knowing teammate, opponent, ball and goal positions.
- This is an intermediate safety build, not yet an intelligent football player. It will not reliably score in open play until proper pitch perception and action calibration are implemented.

## Known limits
- It still does not detect or track teammates, opponents, the ball trajectory, goalkeeper or goalmouth. Therefore it cannot yet select a receiver, calculate shot probability, or defend by marking/interception.
- Not tested: extra time, penalty shoot-outs, cup pages (other than the red PLAY NOW tag), the "Top Picks" screen.
- Adverts: only the skip-arrow style seen so far is recognised. After 90 s stuck the bot presses Back.
- Camera distance needs no setting: the bot only reads fixed on-screen elements and the green player pin.
- It expects the 20:9 phone screen the screenshots came from. Other shapes may need small position changes in `Config.kt`.

## Safety
- The bot only taps the known buttons above. It never taps an advert itself, only its skip arrow.
- Use it only against computer teams. Automation can still breach the game's terms; try a spare account first.
