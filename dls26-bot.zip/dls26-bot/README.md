# DLS Bot (v0.2)

An on-device Android app (Kotlin) that watches the screen and plays DLS 26 matches against computer teams
(for example the Legendary Division fixtures).

## Build it from a phone (no Android Studio)
1. On github.com (phone browser, "Desktop site" helps), create a new repository.
2. Add file > Create new file. Name it `.github/workflows/build.yml` and paste the contents of that file from this zip. Commit.
3. Add file > Upload files. Upload `dls26-bot.zip` itself (do not unzip it). Commit.
4. Open the Actions tab > "Build APK" > wait for the green tick (about 5 to 10 minutes). Open the run and download the `dls-bot-apk` artifact (a zip containing `app-debug.apk`).
5. Unzip it, open the APK to install (allow "install unknown apps" for your browser or file manager).
6. If Android blocks the accessibility service ("restricted setting"): Settings > Apps > DLS Bot > top-right menu > "Allow restricted settings". Then enable DLS Bot under Accessibility.

Push a new `dls26-bot.zip` any time and the build re-runs.

## How it works
1. `CaptureService`: MediaProjection mirrors the screen into a small (640 px wide) frame, about 12 fps.
2. `ScreenDetector`: OpenCV template matching decides which screen is showing (menu, pre-match, cutscene, in-match, paused, half-time, result, error).
3. `PitchVision`: finds the green pin above the player you control.
4. `BotController`: plays a tick when in a match, or taps a whitelisted button between matches.
5. `GestureService`: an AccessibilityService that performs the joystick drag and button taps (multi-touch).

## Calibrated from your screenshots
- Joystick, B (pass), A (shoot) and C (lofted) positions.
- Templates for: home "PLAY NOW", lineup "PLAY", walk-out/replay "TAP TO SKIP", pause button (in match), pause-menu "RESUME".
- The controlled-player pin is found at the right spot in all three in-match frames tested.
- Ball detection by colour did not work (the ball is about 3 px), so v1 does not use it.

## Still missing
- Templates for half-time, full-time/result, and error/reconnect screens (send screenshots of these).
- Match logic is v1: run towards the goal and pass/shoot on timers. It does not defend or read the radar yet.
- Attack direction starts as "left" (measured from your goal replay) and flips at half-time; check it on the first run (`ATTACK_RIGHT` in `Config.kt`).

## Safety
- Outside matches the bot only taps buttons listed in `Config.ALLOWED_BUTTONS`.
- Use it only in modes against computer teams. Automation can still break the game's terms of service; test on a spare account first.
