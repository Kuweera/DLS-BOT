# DLS Bot v1.0

An on-device Android app (Kotlin) that plays DLS 26 fixtures against computer teams: menus, cutscenes,
the match, half-time and full-time adverts, and the rewards screen, then moves on to the next fixture.

## Build it from a phone (no Android Studio)
1. On github.com create a new repository ("Desktop site" in your browser helps).
2. Add file > Create new file. Name it `.github/workflows/build.yml` and paste in the contents of `build.yml`. Commit.
3. Add file > Upload files. Upload `dls26-bot.zip` itself (do not unzip it). Commit.
4. Open the Actions tab > "Build APK". Wait for the green tick (5 to 10 minutes) and download the `dls-bot-apk` file. Unzip it and install `app-debug.apk`.
5. If Android blocks the accessibility service: Settings > Apps > DLS Bot > top-right menu > "Allow restricted settings".
   Then enable DLS Bot under Accessibility.
6. If the build fails, open the failed run, copy the red error text and send it to Claude.

## First run
1. Open DLS Bot. In Settings choose which side you attack in the FIRST half (starts as Left).
2. Press 1 (enable accessibility), 2 (start screen capture), 3 (start bot), then switch to DLS.
3. Start from the line-up screen or the home screen. Watch the first match.
4. If the "Attacking" read-out in the app is wrong, press "Flip attacking direction now" and change the setting.
5. "Show what the bot sees right now" lists every template score for the current screen. Use it on the menu and in a match.

## What it handles
| Screen | Action |
|---|---|
| Home | taps the fixture card marked with the red "PLAY NOW" tag |
| Line-up | taps PLAY |
| Cutscenes, replays, substitutions | taps TAP TO SKIP |
| Half time | waits, flips the attacking direction, taps RESUME after the advert |
| Adverts / Google Play | waits, taps the skip arrow when it appears, presses Back if it opens Google Play |
| Full time | claims bonus rewards (optional), then CONTINUE |
| Defending | alternates SWITCH PLAYER and holds PRESSURE (never slide-tackles) |
| Free kick near goal | shoots |
| Corner | lofted cross |
| Goal kick, throw-in, other restarts | short pass |
| Open play with the ball | runs at goal, passes every ~2 s, shoots every ~5 s |

## How the detection was checked
All detection logic was replayed on your 80 screenshots: 77 of 80 screens were classified as expected;
the 3 "misses" were two Game-settings screens and the black loading screen, now handled. Attack vs defend
(kick labels vs PRESSURE / SWITCH PLAYER) separated perfectly. The Android code itself has not been compiled
or run on a phone yet.

## Known limits
- Attack play is basic: it does not read teammates or opponents, so passes and shots are timed, not chosen.
- Not tested: extra time, penalty shoot-outs, cup pages (other than the red PLAY NOW tag), the "Top Picks" screen.
- Adverts: only the skip-arrow style seen so far is recognised. After 90 s stuck the bot presses Back.
- Camera distance needs no setting: the bot only reads fixed on-screen elements and the green player pin.
- It expects the 20:9 phone screen the screenshots came from. Other shapes may need small position changes in `Config.kt`.

## Safety
- The bot only taps the known buttons above. It never taps an advert itself, only its skip arrow.
- Use it only against computer teams. Automation can still breach the game's terms; try a spare account first.
