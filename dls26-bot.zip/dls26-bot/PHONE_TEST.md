# Phone test for 0.2-phase1 (please report each result)
1. Build via your usual workflow; install; app opens and "Open debug dashboard" appears.  [ ]
2. Dashboard opens without crashing; RUN shows STOPPED.  [ ]
3. Enable accessibility + start capture as before. Dashboard: frame size shown, "newest frame age" small, frames published rising.  [ ]
4. Tick Dry run, press Start, open DLS at the line-up/home screen. Expect: VISION events for screen changes, DECISION lines, CONTROL "gesture not sent result=DRY_RUN". Nothing should be tapped in the game.  [ ]
5. Untick Dry run. Expect the bot to behave like v1.0, plus gesture lines COMPLETED / CANCELLED with took_ms.  [ ]
6. Pause: bot stops pressing; Resume: continues. EMERGENCY STOP: stops at once (a gesture already sent can still finish, under 1 s). Start re-arms.  [ ]
7. In a match press Refresh template scores, then Export log; send the .jsonl from Download/DLSBot plus a screenshot of the dashboard.  [ ]
Known limit: the dashboard is inside the app, so you must leave the game to press Pause/EMERGENCY STOP. A floating button is not built yet.
