# Repository audit (local copy of v1.0 only; the owner's GitHub repo was not accessible)

| File | Role | Spec module | Problems found | Action |
|---|---|---|---|---|
| CaptureService.kt | MediaProjection -> ImageReader 640 px wide, ~12 fps, newest frame to FrameStore | CaptureManager | 640 px is too small to read the radar (player icons ~3 px); no frame counter/age (fixed in 0.2) | Phase 3: raise resolution for the radar region |
| FrameStore.kt | latest Bitmap + scale | CaptureManager | no timestamp/counter (fixed in 0.2) | done |
| ScreenDetector.kt | template matching screen classifier, attack/defend labels | ScreenClassifier | works on 77/80 screenshots offline; scores were only visible as text dump | added scoreMap for dashboard |
| PitchVision.kt | finds the green player pin | (part of Vision) | only the pin; no teammates, opponents, ball, goal | Phase 3: radar reader |
| Gestures.kt / GestureService.kt | input | InputController | joystick = ONE 350 ms stroke per tick, so touch down/up repeats every tick; no result tracking (fixed in 0.2) | Phase 2: continued stroke (continueStroke) after dashboard proves the touch pattern |
| BotController.kt | state machine + all gameplay | StateMachine + Decision | passing/shooting are timers (PASS_EVERY_MS, SHOOT_EVERY_MS); direction comes from a user setting and a half-time flip that radar evidence showed is unreliable; no diagnostics (fixed in 0.2) | Phases 3-5, not touched yet |
| Config.kt | coordinates, thresholds, timers | Config | some values are estimates from screenshots, not calibrated on device | Phase 2 calibration |
| Settings.kt, DebugSaver.kt, MainActivity.kt | prefs, frame saving, control panel | UI | none blocking | MainActivity got a dashboard button |

Why there were no diagnostics: v1.0 kept only a single status string and a score dump; no history, no gesture results (the Boolean from dispatchGesture was thrown away), no frame timing.
