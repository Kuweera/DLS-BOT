# DLS Bot v1.1 — what changed

This is the first safety milestone based on the source archive in the DLS-BOT repository.

1. Possession classification is now conservative: OURS / OPPONENT / UNKNOWN. UNKNOWN causes the controller to wait rather than assume possession.
2. Defensive pressure taps are shorter. The bot still does not perform intelligent marking or interceptions.
3. Open-play timer-based passing and shooting are disabled. The current vision code cannot locate teammates, opponents, the ball and goal reliably, so timed kicks were blind actions and could cause turnovers or own goals.
4. Set-piece actions are still legacy behaviour and must be tested carefully; verify attack direction before running unattended.

Important: the code has not been compiled in this environment. The repository's GitHub Actions workflow must build it before installing the APK. This update is not the final intelligent bot; the next stage is pitch-object detection and tracking, then measured pass/shot calibration.


# DLS Bot v1.2 — Movement and Early Defensive Response

1. Joystick gestures now begin at the joystick centre and drag outward. This is more reliable than beginning at 60% of the radius, which may start outside the active touch area.
2. Open-play forward movement no longer uses the green marker's screen Y position as a joystick direction. That marker indicates the controlled player, not where the bot should move.
3. Forward movement lasts 650 ms instead of 250 ms to reduce the repeated-touch/stutter feel.
4. When opponent possession is detected, the bot immediately moves toward its own half while pressing, and periodically switches player while moving. This is only an interim defensive fallback; it cannot yet chase the actual ball because the current vision system does not track the ball or opponents.

Validation status: source changes made; not compiled or tested on a phone in this environment. Run GitHub Actions before installing. Confirm the configured joystick centre/radius matches the phone's control layout.


## v1.3 movement/pass baseline (2026-10-26)
- Joystick gesture path now stays in contact near the selected direction using tiny movements instead of ending immediately after a centre-to-edge swipe. Test on-device; accessibility gesture timing can vary by Android build.
- Restored a conservative periodic low-kick attempt because v1.2 deliberately disabled all open-play passes. This is NOT intelligent receiver selection; vision does not yet track teammates, opponents or ball.
- Defensive fallback now challenges toward midfield rather than retreating blindly. It still cannot select the nearest defender without ball/player tracking.
- Adds a corner/restart wait guard for an opponent restart when the relevant UI templates are detected. Template recognition may need calibration on actual screenshots.
- Not compiled or device-tested in this environment.
