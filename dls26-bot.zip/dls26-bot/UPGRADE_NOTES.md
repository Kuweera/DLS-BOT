# DLS Bot v1.1 — what changed

This is the first safety milestone based on the source archive in the DLS-BOT repository.

1. Possession classification is now conservative: OURS / OPPONENT / UNKNOWN. UNKNOWN causes the controller to wait rather than assume possession.
2. Defensive pressure taps are shorter. The bot still does not perform intelligent marking or interceptions.
3. Open-play timer-based passing and shooting are disabled. The current vision code cannot locate teammates, opponents, the ball and goal reliably, so timed kicks were blind actions and could cause turnovers or own goals.
4. Set-piece actions are still legacy behaviour and must be tested carefully; verify attack direction before running unattended.

Important: the code has not been compiled in this environment. The repository's GitHub Actions workflow must build it before installing the APK. This update is not the final intelligent bot; the next stage is pitch-object detection and tracking, then measured pass/shot calibration.
