Template PNGs cut from DLS 26 screenshots (resized to 640 px wide, then cropped).

Screen templates:  <SCREEN>__<label>.png
  SCREEN = MENU, PRE_MATCH, CUTSCENE, IN_MATCH, PAUSED, HALF_TIME, RESULT or ERROR
Button templates:  BTN__<label>.png   (only labels in Config.ALLOWED_BUTTONS are ever tapped)

Present now: IN_MATCH__pause, IN_MATCH__rplus, MENU__play_now, PRE_MATCH__form_boost,
CUTSCENE__tap_to_skip, PAUSED__resume, BTN__play_now, BTN__play, BTN__tap_to_skip, BTN__resume.

Still needed (send screenshots): HALF_TIME__*, RESULT__*, ERROR__*, BTN__continue, BTN__ok, BTN__retry.
