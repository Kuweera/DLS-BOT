package com.example.dlsbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display

/**
 * Foreground service that mirrors the screen into a small ImageReader (about 640 px wide, ~12 fps)
 * and publishes the newest frame to [FrameStore].
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "capture"
        @Volatile var instance: CaptureService? = null
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var curW = 0
    private var curH = 0
    private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val t = HandlerThread("capture").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h

        val mgr = getSystemService(MediaProjectionManager::class.java)
        val p = mgr.getMediaProjection(code, data)
        // Android 14+ requires a callback to be registered before creating the display.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, h)
        projection = p

        instance = this
        ensureSize()
        return START_NOT_STICKY
    }

    private fun realSize(): Pair<Int, Int> {
        val dm = getSystemService(DisplayManager::class.java)
        val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        d.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    /** (Re)sizes the capture to match the current screen orientation. Safe to call often. */
    @Synchronized
    fun ensureSize() {
        val p = projection ?: return
        val h = handler ?: return
        val (rw, rh) = realSize()
        val k = Config.CAPTURE_WIDTH.toFloat() / maxOf(rw, rh)
        val tw = (rw * k).toInt().coerceAtLeast(2)
        val th = (rh * k).toInt().coerceAtLeast(2)
        if (tw == curW && th == curH) return

        val newReader = ImageReader.newInstance(tw, th, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener({ r -> onFrame(r) }, h)
        val dpi = resources.displayMetrics.densityDpi

        val existing = display
        if (existing == null) {
            display = p.createVirtualDisplay(
                "dls-capture", tw, th, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, h
            )
        } else {
            // Reuse the same display: Android 14 forbids creating a second one per projection.
            existing.resize(tw, th, dpi)
            existing.surface = newReader.surface
        }
        reader?.close()
        reader = newReader
        curW = tw
        curH = th
        FrameStore.scale = rw.toFloat() / tw
    }

    private fun onFrame(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameAt < 80) return
            lastFrameAt = now

            val plane = img.planes[0]
            val rowPad = plane.rowStride - plane.pixelStride * img.width
            val wide = Bitmap.createBitmap(
                img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            wide.copyPixelsFromBuffer(plane.buffer)
            FrameStore.latest = if (rowPad == 0) {
                wide
            } else {
                Bitmap.createBitmap(wide, 0, 0, img.width, img.height).also { wide.recycle() }
            }
        } finally {
            img.close()
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Screen capture", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("DLS Bot is reading the screen")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        BotHolder.stopIfRunning()
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        display = null
        reader = null
        projection = null
        FrameStore.latest = null
        instance = null
        super.onDestroy()
    }
}
