package com.example.dlsbot

import android.content.Context

/** User choices, saved on the phone. */
object Settings {
    /** Tap the CLAIM buttons on the rewards screen (this plays an advert for each one). */
    @Volatile var claimRewards = true

    /** Save a small picture of any screen the bot cannot recognise for a long time (Pictures/DLSBot). */
    @Volatile var saveUnknownFrames = true

    /** True if your team attacks towards the right side of the screen in the first half. */
    @Volatile var firstHalfAttackRight = false

    private const val FILE = "dlsbot"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        claimRewards = p.getBoolean("claimRewards", true)
        saveUnknownFrames = p.getBoolean("saveUnknownFrames", true)
        firstHalfAttackRight = p.getBoolean("firstHalfAttackRight", false)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("claimRewards", claimRewards)
            .putBoolean("saveUnknownFrames", saveUnknownFrames)
            .putBoolean("firstHalfAttackRight", firstHalfAttackRight)
            .apply()
    }
}
