package com.example.dlsbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Accessibility service whose only job is dispatching taps, drags and the Back action.
 * The user must enable it manually in Settings > Accessibility.
 */
class GestureService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureService? = null

        fun tapStroke(x: Float, y: Float, durationMs: Long): GestureDescription.StrokeDescription {
            val path = Path()
            path.moveTo(x, y)
            return GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
        }

        fun dragStroke(
            x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long
        ): GestureDescription.StrokeDescription {
            val path = Path()
            path.moveTo(x1, y1)
            path.lineTo(x2, y2)
            return GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    /** Presses the phone's Back button. */
    fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    /** Dispatches several strokes at once (multi-touch) and waits until they finish. */
    suspend fun perform(strokes: List<GestureDescription.StrokeDescription>): Boolean =
        suspendCancellableCoroutine { cont ->
            val builder = GestureDescription.Builder()
            strokes.forEach { builder.addStroke(it) }
            val accepted = dispatchGesture(
                builder.build(),
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null
            )
            if (!accepted && cont.isActive) cont.resume(false)
        }
}
