package com.example.dlsbot

enum class RunState { STOPPED, RUNNING, PAUSED, EMERGENCY }

/**
 * What the gesture layer must do with an input request right now. Pure Kotlin, unit-tested.
 *  SEND    - dispatch to the screen
 *  DRY_RUN - log it, do not touch the screen
 *  BLOCKED - paused / emergency stop / stopped: log it, do not touch the screen
 */
enum class GateDecision { SEND, DRY_RUN, BLOCKED }

class RunControl(private val log: EventLog) {
    @Volatile var state: RunState = RunState.STOPPED
        private set
    @Volatile var dryRun: Boolean = false
        private set

    @Synchronized fun start(): Boolean {
        if (state == RunState.RUNNING) return false
        change(RunState.RUNNING, "start")
        return true
    }

    @Synchronized fun pause(): Boolean {
        if (state != RunState.RUNNING) return false
        change(RunState.PAUSED, "pause")
        return true
    }

    @Synchronized fun resume(): Boolean {
        if (state != RunState.PAUSED) return false
        change(RunState.RUNNING, "resume")
        return true
    }

    /** Works from any state. Only start() leaves EMERGENCY, so a stray resume() cannot re-arm the bot. */
    @Synchronized fun emergencyStop() {
        change(RunState.EMERGENCY, "EMERGENCY STOP")
    }

    @Synchronized fun stop() {
        if (state != RunState.STOPPED) change(RunState.STOPPED, "stop")
    }

    @Synchronized fun setDryRun(on: Boolean) {
        if (dryRun == on) return
        dryRun = on
        log.info(Category.SYSTEM, "dry-run ${if (on) "ON: gestures are logged, not sent" else "OFF: gestures are sent"}")
    }

    fun gate(): GateDecision = when {
        state != RunState.RUNNING -> GateDecision.BLOCKED
        dryRun -> GateDecision.DRY_RUN
        else -> GateDecision.SEND
    }

    private fun change(to: RunState, why: String) {
        val from = state
        state = to
        val level = if (to == RunState.EMERGENCY) Level.WARN else Level.INFO
        log.log(Category.SYSTEM, level, "run state $from -> $to ($why)")
    }
}

/** Process-wide run control used by the app. */
object Run {
    val control = RunControl(Log.events)
}
