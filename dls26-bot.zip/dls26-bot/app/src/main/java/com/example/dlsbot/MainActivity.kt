package com.example.dlsbot

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.opencv.android.OpenCVLoader

/** Control panel: settings, start/stop, and a live status read-out. */
class MainActivity : ComponentActivity() {

    private lateinit var statusView: TextView
    private lateinit var scoresView: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { requestCapture() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, result.resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, intent)
            }
        }

    private val refresh = object : Runnable {
        override fun run() {
            val bot = BotHolder.get(this@MainActivity)
            statusView.text = buildString {
                appendLine("Accessibility: ${if (GestureService.instance != null) "on" else "OFF"}")
                appendLine("Screen capture: ${if (FrameStore.latest != null) "on" else "OFF"}")
                appendLine("Bot: ${if (bot.running) "running" else "stopped"}")
                appendLine("Attacking: ${if (bot.attackRight) "RIGHT" else "LEFT"}")
                appendLine("Status: ${bot.status}")
                append("Templates: ${bot.templateSummary()}")
            }
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        check(OpenCVLoader.initLocal()) { "OpenCV failed to load" }
        Settings.load(this)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun label(text: String, size: Float): TextView {
            val t = TextView(this)
            t.text = text
            t.textSize = size
            return t
        }

        fun button(text: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = text
            b.setOnClickListener { onClick() }
            return b
        }

        root.addView(label("DLS Bot", 22f))
        root.addView(label("For matches against computer teams only.", 14f))

        // ---- settings ----
        root.addView(label("\nSettings", 18f))

        val claim = CheckBox(this)
        claim.text = "Claim bonus rewards after full time (watches one advert per reward)"
        claim.isChecked = Settings.claimRewards
        claim.setOnCheckedChangeListener { _, checked ->
            Settings.claimRewards = checked
            Settings.save(this)
        }
        root.addView(claim)

        val saveFrames = CheckBox(this)
        saveFrames.text = "Save pictures of screens the bot cannot recognise (Pictures/DLSBot)"
        saveFrames.isChecked = Settings.saveUnknownFrames
        saveFrames.setOnCheckedChangeListener { _, checked ->
            Settings.saveUnknownFrames = checked
            Settings.save(this)
        }
        root.addView(saveFrames)

        root.addView(label("In the FIRST half my team attacks:", 14f))
        val group = RadioGroup(this)
        group.orientation = RadioGroup.HORIZONTAL
        val left = RadioButton(this)
        left.text = "Left"
        left.id = View.generateViewId()
        val right = RadioButton(this)
        right.text = "Right"
        right.id = View.generateViewId()
        group.addView(left)
        group.addView(right)
        group.check(if (Settings.firstHalfAttackRight) right.id else left.id)
        group.setOnCheckedChangeListener { _, id ->
            Settings.firstHalfAttackRight = (id == right.id)
            Settings.save(this)
        }
        root.addView(group)

        // ---- controls ----
        root.addView(label("\nControls", 18f))
        root.addView(button("1. Enable accessibility service") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2. Start screen capture") {
            if (Build.VERSION.SDK_INT >= 33) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                requestCapture()
            }
        })
        root.addView(button("3. Start bot (then open DLS)") { BotHolder.get(this).start() })
        root.addView(button("Stop bot") { BotHolder.get(this).stop() })
        root.addView(button("Flip attacking direction now") { BotHolder.get(this).flipDirection() })
        root.addView(button("Stop screen capture") {
            stopService(Intent(this, CaptureService::class.java))
        })

        statusView = label("", 15f)
        root.addView(label("\nStatus", 18f))
        root.addView(statusView)

        // ---- diagnostics ----
        root.addView(label("\nDiagnostics", 18f))
        scoresView = label("", 13f)
        root.addView(button("Show what the bot sees right now") {
            scoresView.text = BotHolder.get(this).scoresReport()
        })
        root.addView(scoresView)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun requestCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        super.onPause()
    }
}
