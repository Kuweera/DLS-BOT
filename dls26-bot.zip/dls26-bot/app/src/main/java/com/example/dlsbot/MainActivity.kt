package com.example.dlsbot

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.opencv.android.OpenCVLoader

/** Minimal control panel: enable accessibility, start capture, start/stop the bot. */
class MainActivity : ComponentActivity() {

    private lateinit var statusView: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { requestCapture() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, result.resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, intent)
            }
        }

    private val refresh = object : Runnable {
        override fun run() {
            val bot = BotHolder.get(this@MainActivity)
            statusView.text = buildString {
                appendLine("Accessibility: ${if (GestureService.instance != null) "on" else "OFF"}")
                appendLine("Screen capture: ${if (FrameStore.latest != null) "on" else "OFF"}")
                appendLine("Bot: ${if (bot.running) "running" else "stopped"}")
                appendLine("Status: ${bot.status}")
                append("Templates: ${bot.templateSummary()}")
            }
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        check(OpenCVLoader.initLocal()) { "OpenCV failed to load" }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        statusView = TextView(this).apply { textSize = 15f }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        root.addView(TextView(this).apply {
            text = "DLS Bot\nFor offline and computer-opponent matches only."
            textSize = 18f
        })
        root.addView(button("1. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2. Start screen capture") {
            if (Build.VERSION.SDK_INT >= 33) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                requestCapture()
            }
        })
        root.addView(button("3. Start bot (open DLS first)") {
            BotHolder.get(this).start()
        })
        root.addView(button("Stop bot") { BotHolder.get(this).stop() })
        root.addView(button("Stop screen capture") {
            stopService(Intent(this, CaptureService::class.java))
        })
        root.addView(statusView)
        setContentView(root)
    }

    private fun requestCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        super.onPause()
    }
}
