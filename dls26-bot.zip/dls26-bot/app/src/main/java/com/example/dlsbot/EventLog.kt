package com.example.dlsbot

/**
 * Structured event log. Pure Kotlin (no Android classes) so it can be unit-tested on a plain JVM.
 *
 * Categories follow the pipeline: VISION -> TRACK -> DECISION -> CONTROL -> OUTCOME.
 * TRACK has no producer yet (nothing tracks players or the ball); the dashboard says so instead of faking it.
 */
enum class Category { VISION, TRACK, DECISION, CONTROL, OUTCOME, SYSTEM }

enum class Level { INFO, WARN, ERROR }

data class Event(
    val seq: Long,
    val tMs: Long,
    val category: Category,
    val level: Level,
    val message: String,
    val fields: Map<String, String> = emptyMap()
) {
    fun toJson(): String {
        val sb = StringBuilder()
        sb.append("{\"seq\":").append(seq)
        sb.append(",\"t_ms\":").append(tMs)
        sb.append(",\"cat\":\"").append(category.name).append('"')
        sb.append(",\"level\":\"").append(level.name).append('"')
        sb.append(",\"msg\":\"").append(jsonEscape(message)).append('"')
        if (fields.isNotEmpty()) {
            sb.append(",\"fields\":{")
            var first = true
            for ((k, v) in fields) {
                if (!first) sb.append(',')
                first = false
                sb.append('"').append(jsonEscape(k)).append("\":\"").append(jsonEscape(v)).append('"')
            }
            sb.append('}')
        }
        sb.append('}')
        return sb.toString()
    }

    fun toLine(): String {
        val f = if (fields.isEmpty()) "" else fields.entries.joinToString(" ", " ") { "${it.key}=${it.value}" }
        return String.format("%7.2fs %-8s %-5s %s%s", tMs / 1000.0, category.name, level.name, message, f)
    }
}

internal fun jsonEscape(s: String): String {
    val sb = StringBuilder(s.length + 8)
    for (c in s) {
        when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c < ' ' -> sb.append(String.format("\\u%04x", c.code))
            else -> sb.append(c)
        }
    }
    return sb.toString()
}

/** Thread-safe ring buffer of events. The clock is injectable for tests. */
class EventLog(private val capacity: Int = 1000, private val clock: () -> Long = { System.nanoTime() / 1_000_000 }) {
    private val buf = ArrayDeque<Event>()
    private var seq = 0L
    private val t0 = clock()
    private val counts = HashMap<Category, Long>()

    @Synchronized
    fun log(cat: Category, level: Level, msg: String, fields: Map<String, String> = emptyMap()): Event {
        val e = Event(++seq, clock() - t0, cat, level, msg, fields)
        buf.addLast(e)
        while (buf.size > capacity) buf.removeFirst()
        counts[cat] = (counts[cat] ?: 0L) + 1
        return e
    }

    fun info(cat: Category, msg: String, vararg f: Pair<String, String>) = log(cat, Level.INFO, msg, f.toMap())
    fun warn(cat: Category, msg: String, vararg f: Pair<String, String>) = log(cat, Level.WARN, msg, f.toMap())
    fun error(cat: Category, msg: String, vararg f: Pair<String, String>) = log(cat, Level.ERROR, msg, f.toMap())

    @Synchronized fun snapshot(): List<Event> = buf.toList()

    @Synchronized fun recent(n: Int, minLevel: Level = Level.INFO): List<Event> =
        buf.filter { it.level.ordinal >= minLevel.ordinal }.takeLast(n)

    @Synchronized fun lastOf(cat: Category): Event? = buf.lastOrNull { it.category == cat }

    /** Total events ever logged for a category (not limited by the ring size). */
    @Synchronized fun count(cat: Category): Long = counts[cat] ?: 0L

    @Synchronized fun clear() {
        buf.clear()
        counts.clear()
    }

    /** One JSON object per line. */
    fun exportJsonLines(): String = snapshot().joinToString("\n") { it.toJson() }

    fun exportText(): String = snapshot().joinToString("\n") { it.toLine() }
}

/** Process-wide log used by the app. */
object Log {
    val events = EventLog()
}
