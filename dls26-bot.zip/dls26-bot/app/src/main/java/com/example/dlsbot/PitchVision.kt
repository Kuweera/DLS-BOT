package com.example.dlsbot

import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc

/**
 * Cheap colour-based vision on an RGBA frame (as produced by Utils.bitmapToMat).
 * The marker thresholds were checked against real DLS 26 screenshots: the green pin above the
 * controlled player was found at exactly the right spot in all three in-match frames tested.
 * Ball detection by colour was NOT reliable (the ball is only ~3 px wide at this scale), so v1 does not use it.
 */
object PitchVision {

    private fun hsv(rgba: Mat): Mat {
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        val out = Mat()
        Imgproc.cvtColor(rgb, out, Imgproc.COLOR_RGB2HSV)
        rgb.release()
        return out
    }

    /** Fraction of the frame that is grass. */
    fun coverage(rgba: Mat): Double {
        val h = hsv(rgba)
        val g = Mat()
        Core.inRange(h, Scalar(35.0, 60.0, 40.0), Scalar(85.0, 255.0, 255.0), g)
        val c = Core.countNonZero(g).toDouble() / (rgba.rows() * rgba.cols())
        h.release()
        g.release()
        return c
    }

    /** Position (frame px) of the green pin above the player you control, or null if not visible. */
    fun findMarker(rgba: Mat): Point? {
        val h = hsv(rgba)
        val mask = Mat()
        Core.inRange(
            h,
            Scalar(Config.MARKER_H_MIN, Config.MARKER_S_MIN, Config.MARKER_V_MIN),
            Scalar(Config.MARKER_H_MAX, 255.0, 255.0),
            mask
        )
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        var best: Point? = null
        var bestArea = 0.0
        for (c in contours) {
            val area = Imgproc.contourArea(c)
            if (area < 8 || area > 120) continue
            val box = Imgproc.boundingRect(c)
            val aspect = box.width.toDouble() / box.height
            if (aspect < 0.5 || aspect > 1.4) continue
            if (area > bestArea) {
                bestArea = area
                best = Point(box.x + box.width / 2.0, box.y + box.height / 2.0)
            }
        }
        contours.forEach { it.release() }
        h.release()
        mask.release()
        return best
    }
}
