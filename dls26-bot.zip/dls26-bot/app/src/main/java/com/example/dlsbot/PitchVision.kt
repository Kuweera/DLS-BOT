package com.example.dlsbot

import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc

/**
 * Finds the green pin above the player you control. Tested on real DLS 26 screenshots: found at the
 * right spot in every open-play frame tested (kick-offs, set pieces, goal kicks, corners).
 */
object PitchVision {

    fun findMarker(rgba: Mat): Point? {
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        val hsv = Mat()
        Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        rgb.release()

        val mask = Mat()
        Core.inRange(hsv, Scalar(62.0, 70.0, 205.0), Scalar(80.0, 255.0, 255.0), mask)
        hsv.release()

        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val w = rgba.cols().toDouble()
        val h = rgba.rows().toDouble()
        var best: Point? = null
        var bestArea = 0.0
        for (c in contours) {
            val area = Imgproc.contourArea(c)
            if (area < 8 || area > 120) continue
            val box = Imgproc.boundingRect(c)
            val aspect = box.width.toDouble() / box.height
            if (aspect < 0.5 || aspect > 1.4) continue
            val cx = box.x + box.width / 2.0
            val cy = box.y + box.height / 2.0
            // Ignore the green icons of the substitution / yellow-card panel at the top right.
            if (cx > 0.70 * w && cy < 0.30 * h) continue
            if (area > bestArea) {
                bestArea = area
                best = Point(cx, cy)
            }
        }
        contours.forEach { it.release() }
        mask.release()
        return best
    }
}
