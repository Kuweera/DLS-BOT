package com.example.dlsbot

import android.graphics.PointF

/**
 * Screens the bot can recognise. IN_MATCH is the only one it plays on.
 * CUTSCENE = walk-out / goal replay with "TAP TO SKIP"; PAUSED = the pause menu.
 */
enum class Screen { UNKNOWN, MENU, PRE_MATCH, CUTSCENE, IN_MATCH, PAUSED, HALF_TIME, RESULT, ERROR }

/**
 * All tunable values live here. Positions are fractions of the screen (0..1) in landscape,
 * measured from real DLS 26 screenshots (1612 x 720 phone screen).
 */
object Config {
    /** Width (px) of the downscaled frame used for vision. Templates are cut at this scale. */
    const val CAPTURE_WIDTH = 640

    /** Minimum template-match score (0..1) to accept a screen or button. */
    const val MATCH_THRESHOLD = 0.85

    /**
     * True if your team attacks towards the right side of the screen.
     * Measured from a first-half goal replay: Arnest (red) defended the right goal, so it attacks left.
     * The bot flips this automatically at half-time. Check it on your first run.
     */
    var ATTACK_RIGHT = false

    // On-screen controls (fractions of frame width / height).
    val JOYSTICK_CENTER = PointF(0.188f, 0.690f)
    const val JOYSTICK_RADIUS = 0.055f // drag distance, fraction of frame width
    val BTN_PASS = PointF(0.795f, 0.868f)   // B: low kick (ground pass)
    val BTN_SHOOT = PointF(0.901f, 0.868f)  // A: hard kick (shot)
    val BTN_LOFTED = PointF(0.901f, 0.628f) // C: lofted kick

    // The green pin above the player you control: bright, saturated green-cyan (OpenCV HSV).
    const val MARKER_H_MIN = 62.0
    const val MARKER_H_MAX = 80.0
    const val MARKER_S_MIN = 70.0
    const val MARKER_V_MIN = 205.0

    /** Milliseconds between automatic passes and shots while playing. */
    const val PASS_EVERY_MS = 2000L
    const val SHOOT_EVERY_MS = 4500L

    /**
     * SAFETY WHITELIST: the ONLY buttons the bot will ever tap outside a match, per screen.
     * Each name is a template file `BTN__<name>.png` in assets/templates.
     * MENU "play_now" is the Legendary Division fixture, which is played against computer teams.
     */
    val ALLOWED_BUTTONS: Map<Screen, List<String>> = mapOf(
        Screen.MENU to listOf("play_now"),
        Screen.PRE_MATCH to listOf("play"),
        Screen.CUTSCENE to listOf("tap_to_skip"),
        Screen.PAUSED to listOf("resume"),
        Screen.HALF_TIME to listOf("continue"),
        Screen.RESULT to listOf("continue"),
        Screen.ERROR to listOf("ok", "retry"),
    )
}
