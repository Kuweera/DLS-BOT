package com.example.dlsbot

import android.graphics.PointF

/**
 * Screens the bot recognises.
 * CUTSCENE = anything with "TAP TO SKIP" (walk-out, replays, substitutions).
 * PAUSED   = the pause menu (also shown at half-time, with an ad).
 * RESULT   = full-time stats and rewards screens (both have CONTINUE).
 * UNKNOWN  = loading, adverts, Google Play, anything not recognised.
 */
enum class Screen { UNKNOWN, HOME, LINEUP, CUTSCENE, PAUSED, IN_MATCH, RESULT }

/** A search area as fractions of the frame (left, top, right, bottom). */
class Roi(val l: Float, val t: Float, val r: Float, val b: Float)

/**
 * Everything measured from real DLS 26 screenshots (1612 x 720 phone, landscape).
 * Positions are fractions of the frame so they scale with the capture size.
 */
object Config {
    /** Width (px) of the downscaled frame used for vision. Templates are cut at this scale. */
    const val CAPTURE_WIDTH = 640

    // On-screen buttons (x as a fraction of width, y as a fraction of height).
    val JOYSTICK_CENTER = PointF(0.188f, 0.690f)
    const val JOYSTICK_RADIUS = 0.055f // drag distance, fraction of frame width
    val BTN_B = PointF(0.795f, 0.868f)  // LOW KICK (pass)     / PRESSURE when defending
    val BTN_A = PointF(0.902f, 0.871f)  // HARD KICK (shot)    / SLIDE TACKLE when defending
    val BTN_C = PointF(0.901f, 0.628f)  // LOFTED KICK (cross) / SWITCH PLAYER when defending

    /** From the centre of the red "PLAY NOW" tag to the middle of its fixture card on the home screen. */
    const val HOME_CARD_DX = 0.183f // of width
    const val HOME_CARD_DY = 0.110f // of height

    /** Timing of the simple attacking logic. */
    const val PASS_EVERY_MS = 2200L
    const val SHOOT_EVERY_MS = 5000L

    /** Max CLAIM taps per rewards screen, so a stuck button can never loop forever. */
    const val MAX_CLAIMS = 8

    /** Names of the templates in assets/templates (plus att_B, att_C, def_B, def_C label crops). */
    val TEMPLATES = listOf(
        "resume", "continue", "lineup_play", "lineup_team", "home_tag", "tap_to_skip", "pause",
        "claim", "skip_arrow", "half_time", "ball_icon", "gloves_icon", "yards", "subs_banner",
        "att_B", "att_C", "def_B", "def_C"
    )

    /** Minimum match score per template. Everything not listed uses [DEFAULT_THRESHOLD]. */
    const val DEFAULT_THRESHOLD = 0.82
    val THRESHOLDS: Map<String, Double> = mapOf(
        "pause" to 0.88,
        "tap_to_skip" to 0.80,
        "skip_arrow" to 0.80,
        "claim" to 0.80,
        "subs_banner" to 0.85,
        "ball_icon" to 0.85,
        "gloves_icon" to 0.85,
        "half_time" to 0.85,
    )

    /** Where each template can appear (keeps matching fast and avoids false hits). */
    val ROI: Map<String, Roi> = mapOf(
        "resume" to Roi(0.55f, 0.70f, 0.95f, 0.98f),
        "continue" to Roi(0.70f, 0.82f, 1.00f, 1.00f),
        "lineup_play" to Roi(0.78f, 0.86f, 1.00f, 1.00f),
        "lineup_team" to Roi(0.00f, 0.86f, 0.28f, 1.00f),
        "home_tag" to Roi(0.00f, 0.10f, 1.00f, 0.75f),
        "tap_to_skip" to Roi(0.35f, 0.86f, 0.65f, 1.00f),
        "pause" to Roi(0.02f, 0.00f, 0.14f, 0.14f),
        "claim" to Roi(0.20f, 0.72f, 0.95f, 0.92f),
        "skip_arrow" to Roi(0.75f, 0.00f, 1.00f, 0.25f),
        "half_time" to Roi(0.05f, 0.07f, 0.35f, 0.16f),
        "ball_icon" to Roi(0.72f, 0.00f, 0.97f, 0.13f),
        "gloves_icon" to Roi(0.72f, 0.00f, 0.97f, 0.13f),
        "yards" to Roi(0.60f, 0.10f, 0.85f, 0.30f),
        "subs_banner" to Roi(0.25f, 0.55f, 0.80f, 0.75f),
    )

    fun threshold(name: String): Double = THRESHOLDS[name] ?: DEFAULT_THRESHOLD
}
