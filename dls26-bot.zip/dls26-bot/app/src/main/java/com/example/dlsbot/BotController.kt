package com.example.dlsbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc

/**
 * The bot loop. Each frame it works out which screen is showing and does the one thing that screen needs:
 *  - menus: tap the next fixture, PLAY, TAP TO SKIP, RESUME, CLAIM, CONTINUE
 *  - adverts / unknown screens: wait, tap the skip arrow when it appears, press Back if it opens Google Play
 *  - in a match: attack, defend, or take set pieces
 * It never taps anything that is not one of those known buttons.
 */
class BotController(context: Context) {

    private val appContext = context.applicationContext
    private val det by lazy { ScreenDetector(appContext) }
    private var job: Job? = null

    @Volatile var status: String = "Stopped"
        private set

    /** Which way your team is attacking right now (flips at half-time; can be flipped by hand). */
    @Volatile var attackRight: Boolean = false

    val running: Boolean get() = job?.isActive == true

    fun start() {
        if (running) return
        Settings.load(appContext)
        attackRight = Settings.firstHalfAttackRight
        newMatch = true
        job = CoroutineScope(Dispatchers.Default).launch { runLoop() }
    }

    fun stop() {
        job?.cancel()
        job = null
        status = "Stopped"
    }

    fun flipDirection() {
        attackRight = !attackRight
    }

    fun templateSummary(): String = det.templateSummary()

    /** Scores of every template on the current frame, for checking detection on your phone. */
    fun scoresReport(): String {
        val bmp = FrameStore.latest ?: return "No frame yet: start screen capture first."
        val rgba = Mat()
        val gray = Mat()
        return try {
            Utils.bitmapToMat(bmp, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            "Screen: ${det.classify(gray)}  (${gray.cols()}x${gray.rows()})\n" + det.debugScores(gray)
        } finally {
            rgba.release()
            gray.release()
        }
    }

    // ---- state ----
    private var screenSince = 0L
    private var unknownSince = 0L
    private var skipTappedAt = 0L
    private var lastBack = 0L
    private var backs = 0
    private var savedFrames = 0
    private var savedThisEpisode = false
    private var lastTap = 0L
    private var claimsThisResult = 0
    private var newMatch = true
    private var lastHalfFlip = 0L

    private var wasAttacking = true
    private var attackStart = 0L
    private var lastSwitch = 0L
    private var deadSince = 0L
    private var deadSeenAt = 0L
    private var lastDead = 0L

    private suspend fun runLoop() {
        var prev = Screen.UNKNOWN
        var lastEnsure = 0L
        var lastBmp: Bitmap? = null
        screenSince = SystemClock.uptimeMillis()

        while (currentCoroutineContext().isActive) {
            val now = SystemClock.uptimeMillis()
            if (now - lastEnsure > 1000) {
                CaptureService.instance?.ensureSize()
                lastEnsure = now
            }
            if (GestureService.instance == null) {
                status = "Enable the DLS Bot accessibility service"
                delay(500)
                continue
            }
            val bmp = FrameStore.latest
            if (bmp == null) {
                status = "Waiting for screen capture"
                delay(300)
                continue
            }
            if (bmp === lastBmp) {
                delay(40)
                continue
            }
            lastBmp = bmp

            val rgba = Mat()
            val gray = Mat()
            try {
                Utils.bitmapToMat(bmp, rgba)
                Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                val screen = det.classify(gray)

                if (screen != prev) {
                    screenSince = now
                    if (screen == Screen.LINEUP) newMatch = true
                    if (screen != Screen.UNKNOWN) {
                        unknownSince = 0L
                        skipTappedAt = 0L
                        backs = 0
                        savedThisEpisode = false
                    }
                    if (screen == Screen.HOME || screen == Screen.LINEUP ||
                        screen == Screen.CUTSCENE || screen == Screen.IN_MATCH
                    ) {
                        claimsThisResult = 0
                    }
                    prev = screen
                }

                when (screen) {
                    Screen.HOME -> doHome(gray, now)
                    Screen.LINEUP -> doLineup(gray, now)
                    Screen.CUTSCENE -> doCutscene(gray, now)
                    Screen.PAUSED -> doPaused(gray, now)
                    Screen.RESULT -> doResult(gray, now)
                    Screen.IN_MATCH -> doMatch(rgba, gray, now)
                    Screen.UNKNOWN -> doUnknown(gray, bmp, now)
                }
            } finally {
                rgba.release()
                gray.release()
            }
        }
    }

    // ---------------- menus ----------------

    private suspend fun doHome(gray: Mat, now: Long) {
        status = "Home: opening the next fixture"
        if (now - screenSince > 1500 && now - lastTap > 2500) {
            val p = det.find(gray, "home_tag")
            if (p != null) {
                val x = p.x + Config.HOME_CARD_DX * gray.cols()
                val y = p.y + Config.HOME_CARD_DY * gray.rows()
                Gestures.tap(x.toFloat(), y.toFloat())
                lastTap = SystemClock.uptimeMillis()
            }
        }
        delay(300)
    }

    private suspend fun doLineup(gray: Mat, now: Long) {
        status = "Line-up: pressing PLAY"
        if (now - screenSince > 1000 && now - lastTap > 2500) {
            val p = det.find(gray, "lineup_play")
            if (p != null) {
                Gestures.tap(p.x.toFloat(), p.y.toFloat())
                lastTap = SystemClock.uptimeMillis()
            }
        }
        delay(300)
    }

    private suspend fun doCutscene(gray: Mat, now: Long) {
        status = "Skipping cutscene"
        if (now - lastTap > 1200) {
            val p = det.find(gray, "tap_to_skip")
            if (p != null) {
                Gestures.tap(p.x.toFloat(), p.y.toFloat())
            } else {
                // Substitution banners fade the text out: tap where it normally is.
                Gestures.tap(gray.cols() * 0.5f, gray.rows() * 0.94f)
            }
            lastTap = SystemClock.uptimeMillis()
        }
        delay(250)
    }

    private suspend fun doPaused(gray: Mat, now: Long) {
        status = "Paused: pressing RESUME"
        if (now - screenSince > 1200 && now - lastTap > 2000) {
            val p = det.find(gray, "resume")
            if (p != null) {
                Gestures.tap(p.x.toFloat(), p.y.toFloat())
                lastTap = SystemClock.uptimeMillis()
            }
        }
        delay(300)
    }

    private suspend fun doResult(gray: Mat, now: Long) {
        status = "Full time"
        if (now - lastTap < 1500) {
            delay(200)
            return
        }
        if (Settings.claimRewards && claimsThisResult < Config.MAX_CLAIMS) {
            val claim = det.find(gray, "claim")
            if (claim != null) {
                status = "Rewards: claiming (watching an advert)"
                claimsThisResult++
                Gestures.tap(claim.x.toFloat(), claim.y.toFloat())
                lastTap = SystemClock.uptimeMillis()
                return
            }
        }
        // Wait a little so greyed-out CLAIM buttons have time to light up before moving on.
        if (now - screenSince > 3000) {
            val p = det.find(gray, "continue")
            if (p != null) {
                status = "Full time: CONTINUE"
                Gestures.tap(p.x.toFloat(), p.y.toFloat())
                lastTap = SystemClock.uptimeMillis()
            }
        }
        delay(250)
    }

    // ---------------- adverts and unknown screens ----------------

    private suspend fun doUnknown(gray: Mat, bmp: Bitmap, now: Long) {
        if (unknownSince == 0L) unknownSince = now
        val dur = now - unknownSince
        status = "Unknown screen (advert or loading) for ${dur / 1000}s"

        val arrow = det.find(gray, "skip_arrow")
        if (arrow != null && now - skipTappedAt > 2500) {
            status = "Advert finished: tapping the skip arrow"
            Gestures.tap(arrow.x.toFloat(), arrow.y.toFloat())
            skipTappedAt = SystemClock.uptimeMillis()
        } else if (skipTappedAt > 0 && now - skipTappedAt > 4000 && now - lastBack > 3000 && backs < 3) {
            // The arrow opened Google Play (or another page): Back returns to the game.
            status = "Pressing Back to return to the game"
            Gestures.back()
            lastBack = SystemClock.uptimeMillis()
            backs++
        } else if (dur > 90_000 && now - lastBack > 20_000) {
            status = "Stuck for over 90 s: pressing Back"
            Gestures.back()
            lastBack = SystemClock.uptimeMillis()
        }

        if (dur > 25_000 && Settings.saveUnknownFrames && !savedThisEpisode && savedFrames < 15) {
            if (DebugSaver.save(appContext, bmp, "unknown")) savedFrames++
            savedThisEpisode = true
        }
        delay(300)
    }

    // ---------------- the match ----------------

    private suspend fun doMatch(rgba: Mat, gray: Mat, now: Long) {
        val w = gray.cols()
        val h = gray.rows()

        if (newMatch) {
            // First moments of a new match: your team attacks the side chosen in Settings in the first half.
            attackRight = Settings.firstHalfAttackRight
            newMatch = false
            attackStart = now
            lastHalfFlip = 0L
        }

        if (det.has(gray, "half_time")) {
            if (now - lastHalfFlip > 120_000) {
                attackRight = !attackRight
                lastHalfFlip = now
            }
            status = "Half time"
            delay(400)
            return
        }

        val possession = det.possessionState(gray)
        val attacking = possession == PossessionState.OURS
        if (attacking && !wasAttacking) attackStart = now
        wasAttacking = attacking

        val pin = PitchVision.findMarker(rgba)
        val dir = if (attackRight) 1f else -1f
        // The green marker's screen Y coordinate is NOT a target direction. Using it
        // made the joystick point up/down based on where the controlled player happened
        // to appear, causing backwards/sideways movement. Keep a neutral vertical axis
        // until actual ball/player tracking is available.
        val dy = 0f

        // Ambiguous button labels are not evidence of possession. Freeze controls rather than
        // accidentally dribbling or kicking for the wrong team.
        if (possession == PossessionState.UNKNOWN) {
            status = "Match: possession unclear; pausing to avoid a wrong-team action"
            delay(180)
            return
        }

        // Interim defending behaviour: do not stand still waiting for the opponent to
        // reach the box. Move toward our own half immediately and apply controlled pressure.
        // This is deliberately a fallback, not true ball-oriented defending: reliable
        // interception requires tracking the ball and opponent positions first.
        if (possession == PossessionState.OPPONENT) {
            status = "Defending: retreating and pressing (ball tracking upgrade needed)"
            val defensiveDir = -dir
            if (now - lastSwitch > 2400) {
                // Switch player while moving toward our own half, then continue pressing.
                Gestures.act(w, h, defensiveDir, 0f, Config.BTN_C, 70, 600)
                lastSwitch = SystemClock.uptimeMillis()
                delay(100)
            }
            Gestures.act(w, h, defensiveDir, 0f, Config.BTN_B, 360, 650)
            delay(100)
            return
        }

        // Dead ball (kick-off restarts excluded): free kick, corner, goal kick or throw-in.
        if (det.has(gray, "ball_icon")) {
            if (deadSince == 0L || now - deadSeenAt > 1500) deadSince = now
            deadSeenAt = now
            if (now - deadSince < 900 || now - lastDead < 1800) {
                delay(150)
                return
            }
            lastDead = now
            val gloves = det.has(gray, "gloves_icon")
            if (gloves && det.has(gray, "yards")) {
                status = "Free kick: shooting"
                Gestures.act(w, h, dir, 0f, Config.BTN_A, 650, 650)
            } else if (gloves) {
                status = "Corner: crossing"
                var cy = 0f
                if (pin != null) cy = ((0.35 - pin.y / h) * 2.0).toFloat().coerceIn(-0.8f, 0.8f)
                Gestures.act(w, h, -dir * 0.8f, cy, Config.BTN_C, 450, 450)
            } else {
                status = "Restart: short pass"
                Gestures.act(w, h, dir, dy, Config.BTN_B, 80, 500)
            }
            attackStart = SystemClock.uptimeMillis()
            return
        } else if (now - deadSeenAt > 1500) {
            deadSince = 0L
        }

        // SAFETY MILESTONE: do not fire blind passes/shots on a timer. Until the vision layer can
        // locate teammates, opponents, ball and goal, a timed kick is as likely to lose possession
        // or send the ball the wrong way as it is to help. Carry the ball briefly instead.
        status = "Attacking ${if (attackRight) "right" else "left"}: steady forward movement; no blind pass/shot" +
            if (pin == null) " (player marker not seen)" else ""
        // A 250 ms pulse felt like repeated taps. Hold a centre-origin joystick drag longer
        // so DLS has time to register continuous movement. This remains a basic carry action;
        // intelligent passing needs teammate/defender/ball tracking.
        Gestures.act(w, h, dir, dy, null, 0, 650)
    }
}

/** Single shared controller so the Activity and services see the same bot. */
object BotHolder {
    private var controller: BotController? = null

    fun get(context: Context): BotController =
        controller ?: BotController(context).also { controller = it }

    fun stopIfRunning() {
        controller?.stop()
    }
}
