package com.example.dlsbot

import android.content.Context
import android.graphics.PointF
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.opencv.android.Utils
import org.opencv.core.Mat

/**
 * The bot loop: look at the latest frame, work out which screen it is, then either play a tick of the
 * match or tap one of the whitelisted buttons ([Config.ALLOWED_BUTTONS]). Nothing else is ever tapped.
 */
class BotController(context: Context) {

    private val appContext = context.applicationContext
    private val detector by lazy { ScreenDetector(appContext) }
    private var job: Job? = null

    @Volatile var status: String = "Stopped"
        private set

    val running: Boolean get() = job?.isActive == true

    fun start() {
        if (running) return
        job = CoroutineScope(Dispatchers.Default).launch { runLoop() }
    }

    fun stop() {
        job?.cancel()
        job = null
        status = "Stopped"
    }

    fun templateSummary(): String = detector.templateSummary()

    private suspend fun runLoop() {
        var lastTap = 0L
        var lastEnsure = 0L
        var previous = Screen.UNKNOWN
        while (currentCoroutineContext().isActive) {
            val now = SystemClock.uptimeMillis()
            if (now - lastEnsure > 1000) {
                CaptureService.instance?.ensureSize()
                lastEnsure = now
            }
            if (GestureService.instance == null) {
                status = "Enable the DLS Bot accessibility service"
                delay(500)
                continue
            }
            val bmp = FrameStore.latest
            if (bmp == null) {
                status = "Waiting for screen capture"
                delay(300)
                continue
            }

            val frame = Mat()
            try {
                Utils.bitmapToMat(bmp, frame)
                val screen = detector.classify(frame)
                status = "Screen: $screen"

                // Teams swap ends at half-time, so flip the attacking direction once per half-time screen.
                if (screen == Screen.HALF_TIME && previous != Screen.HALF_TIME) {
                    Config.ATTACK_RIGHT = !Config.ATTACK_RIGHT
                }
                previous = screen

                when (screen) {
                    Screen.IN_MATCH -> playTick(frame)
                    Screen.UNKNOWN -> delay(250)
                    else -> {
                        if (now - lastTap > 1200 && tapAllowedButton(frame, screen)) {
                            lastTap = SystemClock.uptimeMillis()
                        }
                        delay(200)
                    }
                }
            } finally {
                frame.release()
            }
        }
    }

    private suspend fun tapAllowedButton(frame: Mat, screen: Screen): Boolean {
        val names = Config.ALLOWED_BUTTONS[screen] ?: return false
        for (name in names) {
            val p = detector.find(frame, name) ?: continue
            status = "Screen: $screen, tapping $name"
            Gestures.tap(p.x.toFloat(), p.y.toFloat())
            return true
        }
        return false
    }

    // --- Match logic (version 1: intentionally simple) ---
    // Runs the player you control towards the opponent's goal, drifting back to the middle of the pitch,
    // and passes / shoots on a timer. Smarter decisions (using the radar, defending) come later.

    private var lastPass = 0L
    private var lastShot = 0L

    private suspend fun playTick(frame: Mat) {
        val w = frame.cols()
        val h = frame.rows()
        val marker = PitchVision.findMarker(frame)

        val dx = if (Config.ATTACK_RIGHT) 1f else -1f
        var dy = 0f
        if (marker != null) {
            // Gently steer towards the vertical middle of the screen so we don't run into the touchline.
            dy = ((0.55 - marker.y / h) * 0.8).toFloat()
        }

        val now = SystemClock.uptimeMillis()
        var button: PointF? = null
        if (marker != null) {
            if (now - lastShot > Config.SHOOT_EVERY_MS) {
                button = Config.BTN_SHOOT
                lastShot = now
            } else if (now - lastPass > Config.PASS_EVERY_MS) {
                button = Config.BTN_PASS
                lastPass = now
            }
        }

        status = if (marker != null) {
            "Playing: controlling player at ${marker.x.toInt()},${marker.y.toInt()}"
        } else {
            "Playing: player marker not visible"
        }
        Gestures.act(w, h, dx, dy, button)
    }
}

/** Single shared controller so the Activity and services see the same bot. */
object BotHolder {
    private var controller: BotController? = null

    fun get(context: Context): BotController =
        controller ?: BotController(context).also { controller = it }

    fun stopIfRunning() {
        controller?.stop()
    }
}
