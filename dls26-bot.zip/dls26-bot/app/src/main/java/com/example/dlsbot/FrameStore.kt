package com.example.dlsbot

import android.graphics.Bitmap

/** Shared latest frame from CaptureService, read by the bot loop. */
object FrameStore {
    @Volatile var latest: Bitmap? = null

    /** real screen px = frame px * scale */
    @Volatile var scale: Float = 1f
}
