package com.example.dlsbot

import android.graphics.Bitmap
import android.os.SystemClock

/** Shared latest frame from CaptureService, read by the bot loop. */
object FrameStore {
    @Volatile var latest: Bitmap? = null
        set(value) {
            field = value
            if (value != null) {
                producedCount++
                latestAtMs = SystemClock.uptimeMillis()
            }
        }

    /** real screen px = frame px * scale */
    @Volatile var scale: Float = 1f

    /** Frames published by CaptureService since the app started. */
    @Volatile var producedCount = 0L
        private set

    /** uptimeMillis when the newest frame was published (0 = none yet). */
    @Volatile var latestAtMs = 0L
        private set
}
