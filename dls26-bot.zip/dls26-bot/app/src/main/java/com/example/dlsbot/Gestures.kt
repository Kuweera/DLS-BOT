package com.example.dlsbot

import android.accessibilityservice.GestureDescription
import android.graphics.PointF
import android.os.SystemClock
import kotlin.math.hypot

/**
 * High-level input helpers. Frame coordinates are scaled up to the real screen here.
 * Every request passes through [dispatch], which is the single place that checks the run state
 * (paused / emergency stop / dry-run) and records what was sent and what Android reported back.
 */
object Gestures {

    val stats = GestureStats()
    val contact = ContactTracker()

    private fun tapInfo(x: Float, y: Float, ms: Long, role: String) =
        StrokeInfo("tap", role, x, y, x, y, ms.coerceAtLeast(1))

    /** Taps a point given in capture-frame pixels. */
    suspend fun tap(x: Float, y: Float) {
        val k = FrameStore.scale
        val info = tapInfo(x * k, y * k, 60, "tap")
        dispatch(listOf(info)) { listOf(GestureService.tapStroke(info.x1, info.y1, info.durationMs)) }
    }

    fun back() {
        val id = Gestures.stats.newId()
        val now = SystemClock.uptimeMillis()
        val result = when {
            Run.control.gate() == GateDecision.DRY_RUN -> GestureResult.DRY_RUN
            Run.control.gate() == GateDecision.BLOCKED -> GestureResult.BLOCKED
            GestureService.instance == null -> GestureResult.NO_SERVICE
            else -> {
                GestureService.instance?.back()
                GestureResult.COMPLETED // Android gives no callback for Back; "COMPLETED" means "requested".
            }
        }
        stats.record(GestureRecord(id, listOf(StrokeInfo("tap", "back", 0f, 0f, 0f, 0f, 0)), result, now, now))
        Log.events.log(
            Category.CONTROL, if (result == GestureResult.NO_SERVICE) Level.WARN else Level.INFO,
            "BACK #$id", mapOf("result" to result.name)
        )
    }

    /**
     * Pushes the virtual stick in direction (dirX, dirY) for [moveMs] and, at the same time, presses
     * an on-screen button for [holdMs] (a short tap is about 80 ms, hold longer for more power or pressure).
     * Pass a null button to only move, and a direction of (0, 0) to only press.
     */
    suspend fun act(
        frameW: Int, frameH: Int, dirX: Float, dirY: Float,
        button: PointF?, holdMs: Long, moveMs: Long
    ) {
        val k = FrameStore.scale
        val infos = ArrayList<StrokeInfo>()

        val len = hypot(dirX, dirY)
        if (len > 0.1f && moveMs > 0) {
            val cx = Config.JOYSTICK_CENTER.x * frameW
            val cy = Config.JOYSTICK_CENTER.y * frameH
            val r = Config.JOYSTICK_RADIUS * frameW
            val nx = dirX / len
            val ny = dirY / len
            // v1.3: begin at the joystick centre, then push outward (60% start can miss the touch zone).
            infos.add(
                StrokeInfo(
                    "drag", "stick",
                    cx * k, cy * k,
                    (cx + nx * r) * k, (cy + ny * r) * k, moveMs.coerceAtLeast(1)
                )
            )
        }
        if (button != null) {
            infos.add(tapInfo(button.x * frameW * k, button.y * frameH * k, holdMs, "button"))
        }
        if (infos.isEmpty()) return
        dispatch(infos) {
            infos.map {
                if (it.kind == "drag") GestureService.dragStroke(it.x1, it.y1, it.x2, it.y2, it.durationMs)
                else GestureService.tapStroke(it.x1, it.y1, it.durationMs)
            }
        }
    }

    private suspend fun dispatch(
        infos: List<StrokeInfo>,
        build: () -> List<GestureDescription.StrokeDescription>
    ) {
        val id = stats.newId()
        val started = SystemClock.uptimeMillis()
        val desc = infos.joinToString("; ") { it.describe() }

        val gate = Run.control.gate()
        if (gate != GateDecision.SEND) {
            val r = if (gate == GateDecision.DRY_RUN) GestureResult.DRY_RUN else GestureResult.BLOCKED
            stats.record(GestureRecord(id, infos, r, started, started))
            Log.events.info(Category.CONTROL, "gesture #$id not sent", "result" to r.name, "strokes" to desc)
            return
        }
        val service = GestureService.instance
        if (service == null) {
            stats.record(GestureRecord(id, infos, GestureResult.NO_SERVICE, started, started))
            Log.events.warn(Category.CONTROL, "gesture #$id: accessibility service not connected", "strokes" to desc)
            return
        }

        contact.onDispatch(infos)
        Log.events.info(Category.CONTROL, "gesture #$id dispatched", "strokes" to desc)
        val result = try {
            service.perform(build())
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.events.error(Category.CONTROL, "gesture #$id threw ${e.javaClass.simpleName}: ${e.message}")
            GestureResult.REJECTED
        } finally {
            contact.onFinished(infos)
        }
        val finished = SystemClock.uptimeMillis()
        stats.record(GestureRecord(id, infos, result, started, finished))
        val lvl = if (result == GestureResult.COMPLETED) Level.INFO else Level.WARN
        Log.events.log(
            Category.OUTCOME, lvl, "gesture #$id ${result.name}",
            mapOf("took_ms" to (finished - started).toString())
        )
    }
}
