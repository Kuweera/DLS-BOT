package com.example.dlsbot

import android.accessibilityservice.GestureDescription
import android.graphics.PointF
import kotlin.math.hypot

/** High-level input helpers. Frame coordinates are scaled up to the real screen here. */
object Gestures {

    /** Taps a point given in capture-frame pixels. */
    suspend fun tap(x: Float, y: Float) {
        val service = GestureService.instance ?: return
        val k = FrameStore.scale
        service.perform(listOf(GestureService.tapStroke(x * k, y * k, 60)))
    }

    fun back() {
        GestureService.instance?.back()
    }

    /**
     * Pushes the virtual stick in direction (dirX, dirY) for [moveMs] and, at the same time, presses
     * an on-screen button for [holdMs] (a short tap is about 80 ms, hold longer for more power or pressure).
     * Pass a null button to only move, and a direction of (0, 0) to only press.
     */
    suspend fun act(
        frameW: Int, frameH: Int, dirX: Float, dirY: Float,
        button: PointF?, holdMs: Long, moveMs: Long
    ) {
        val service = GestureService.instance ?: return
        val k = FrameStore.scale
        val strokes = ArrayList<GestureDescription.StrokeDescription>()

        val len = hypot(dirX, dirY)
        if (len > 0.1f && moveMs > 0) {
            val cx = Config.JOYSTICK_CENTER.x * frameW
            val cy = Config.JOYSTICK_CENTER.y * frameH
            val r = Config.JOYSTICK_RADIUS * frameW
            val nx = dirX / len
            val ny = dirY / len
            // Begin at the joystick centre, then push outward. Starting at 60% radius
            // can land outside the active touch zone on some DLS layouts and creates
            // the short, repeated "tapping" movement reported on some phones.
            strokes.add(
                GestureService.dragStroke(
                    cx * k, cy * k,
                    (cx + nx * r) * k, (cy + ny * r) * k, moveMs
                )
            )
        }
        if (button != null) {
            strokes.add(GestureService.tapStroke(button.x * frameW * k, button.y * frameH * k, holdMs))
        }
        if (strokes.isNotEmpty()) service.perform(strokes)
    }
}
