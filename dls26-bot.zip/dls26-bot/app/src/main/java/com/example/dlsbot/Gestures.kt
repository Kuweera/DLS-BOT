package com.example.dlsbot

import android.graphics.PointF

/** High-level input helpers. All coordinates are in capture-frame pixels; they are scaled to the real screen here. */
object Gestures {

    suspend fun tap(x: Float, y: Float) {
        val service = GestureService.instance ?: return
        val k = FrameStore.scale
        service.perform(listOf(GestureService.tapStroke(x * k, y * k, 60)))
    }

    /**
     * Holds the joystick in direction (dirX, dirY) for one short stroke and optionally taps an action button
     * at the same time. Call repeatedly to keep running.
     *
     * @param button button position as a fraction of the frame, or null for no press
     */
    suspend fun act(frameW: Int, frameH: Int, dirX: Float, dirY: Float, button: PointF?) {
        val service = GestureService.instance ?: return
        val k = FrameStore.scale
        val strokes = mutableListOf<android.accessibilityservice.GestureDescription.StrokeDescription>()

        val cx = Config.JOYSTICK_CENTER.x * frameW
        val cy = Config.JOYSTICK_CENTER.y * frameH
        val r = Config.JOYSTICK_RADIUS * frameW
        val len = kotlin.math.hypot(dirX, dirY)
        if (len > 0.1f) {
            val nx = dirX / len
            val ny = dirY / len
            strokes += GestureService.dragStroke(
                cx * k, cy * k, (cx + nx * r) * k, (cy + ny * r) * k, 180
            )
        }
        if (button != null) {
            strokes += GestureService.tapStroke(button.x * frameW * k, button.y * frameH * k, 60)
        }
        if (strokes.isNotEmpty()) service.perform(strokes)
    }
}
