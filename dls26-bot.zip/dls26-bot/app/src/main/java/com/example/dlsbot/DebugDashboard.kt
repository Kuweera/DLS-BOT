package com.example.dlsbot

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import kotlin.concurrent.thread

/**
 * Debug dashboard (Phase 1). It only READS state and sends run-control commands; it changes no gameplay.
 * Everything shown is measured or reported by Android. Items that do not exist yet say so.
 */
class DebugDashboard : ComponentActivity() {

    private lateinit var body: TextView
    private lateinit var scoresView: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val refresh = object : Runnable {
        override fun run() {
            body.text = render()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.load(this)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun button(text: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = text
            b.setOnClickListener { onClick() }
            return b
        }

        val title = TextView(this)
        title.text = "Debug dashboard"
        title.textSize = 20f
        root.addView(title)

        val bot = { BotHolder.get(this) }

        val emergency = button("EMERGENCY STOP") { bot().emergencyStop() }
        root.addView(emergency)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        fun rowButton(text: String, onClick: () -> Unit) {
            val b = button(text, onClick)
            row1.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        rowButton("Start") { bot().start() }
        rowButton("Pause") { bot().pause() }
        rowButton("Resume") { bot().resume() }
        root.addView(row1)

        val dry = CheckBox(this)
        dry.text = "Dry run (decisions are logged, no touch is sent)"
        dry.isChecked = Run.control.dryRun
        dry.setOnCheckedChangeListener { _, on -> Run.control.setDryRun(on) }
        root.addView(dry)

        root.addView(button("Refresh template scores") { refreshScores() })
        scoresView = TextView(this)
        scoresView.textSize = 12f
        scoresView.typeface = android.graphics.Typeface.MONOSPACE
        root.addView(scoresView)

        root.addView(button("Export log to Downloads") { exportLog() })
        root.addView(button("Clear log") { Log.events.clear() })

        body = TextView(this)
        body.textSize = 12f
        body.typeface = android.graphics.Typeface.MONOSPACE
        root.addView(body)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        super.onPause()
    }

    private fun refreshScores() {
        scoresView.text = "computing..."
        thread {
            val text = try {
                BotHolder.get(this).scoresSnapshot()
            } catch (e: Throwable) {
                Log.events.error(Category.VISION, "score snapshot failed: ${e.javaClass.simpleName}: ${e.message}")
                "failed: ${e.message}"
            }
            runOnUiThread { scoresView.text = text }
        }
    }

    private fun render(): String {
        val bot = BotHolder.get(this)
        val now = SystemClock.uptimeMillis()
        val sb = StringBuilder()

        sb.appendLine("RUN: ${Run.control.state}   dry-run: ${if (Run.control.dryRun) "ON" else "off"}")
        sb.appendLine("accessibility service: ${if (GestureService.instance != null) "connected" else "NOT connected"}")
        sb.appendLine()

        sb.appendLine("CAPTURE")
        val f = FrameStore.latest
        if (f == null) {
            sb.appendLine("  no frame")
        } else {
            sb.appendLine("  frame ${f.width}x${f.height}  scale x${"%.2f".format(FrameStore.scale)}")
            sb.appendLine("  newest frame age: ${now - FrameStore.latestAtMs} ms")
        }
        sb.appendLine("  frames published: ${FrameStore.producedCount}")
        sb.appendLine("  frames processed: ${bot.framesProcessed}   skipped: ${bot.framesSkipped}")
        sb.appendLine("  classify: ${bot.lastClassifyMs} ms   whole loop pass: ${bot.lastLoopMs} ms (includes waiting for gestures)")
        sb.appendLine()

        sb.appendLine("VISION")
        sb.appendLine("  screen: ${bot.currentScreen ?: "none yet"}")
        sb.appendLine("  (template scores: press Refresh)")
        sb.appendLine("TRACK")
        sb.appendLine("  NOT IMPLEMENTED: no player, ball or possession tracking exists yet")
        sb.appendLine()

        sb.appendLine("DECISION")
        sb.appendLine("  ${bot.status}")
        sb.appendLine()

        sb.appendLine("CONTROL")
        val g = Gestures.stats.last
        if (g == null) {
            sb.appendLine("  no gesture yet")
        } else {
            sb.appendLine("  last #${g.id}: ${g.result}  (${g.finishedMs - g.startedMs} ms)")
            for (s in g.strokes) sb.appendLine("    ${s.describe()}")
        }
        val c = Gestures.contact
        sb.appendLine("  stick stroke in flight: ${c.stickInFlight}  (derived from dispatch/callback, not read from the game)")
        sb.appendLine("  stick touches sent: ${c.stickTouchesSent}   released: ${c.stickReleases}")
        sb.appendLine(
            "  results: completed ${Gestures.stats.count(GestureResult.COMPLETED)}, " +
                "cancelled ${Gestures.stats.count(GestureResult.CANCELLED)}, " +
                "rejected ${Gestures.stats.count(GestureResult.REJECTED)}, " +
                "dry-run ${Gestures.stats.count(GestureResult.DRY_RUN)}, " +
                "blocked ${Gestures.stats.count(GestureResult.BLOCKED)}"
        )
        sb.appendLine()

        sb.appendLine("WARNINGS / ERRORS (last 8)")
        val bad = Log.events.recent(8, Level.WARN)
        if (bad.isEmpty()) sb.appendLine("  none") else bad.forEach { sb.appendLine("  " + it.toLine()) }
        sb.appendLine()

        sb.appendLine("EVENTS (last 20 of ${Log.events.snapshot().size} kept)")
        Log.events.recent(20).forEach { sb.appendLine(it.toLine()) }
        return sb.toString()
    }

    private fun exportLog() {
        val name = "dlsbot_log_${System.currentTimeMillis()}.jsonl"
        val text = Log.events.exportJsonLines()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Downloads.DISPLAY_NAME, name)
                v.put(MediaStore.Downloads.MIME_TYPE, "application/json")
                v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/DLSBot")
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                    ?: throw IllegalStateException("could not create file")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Download/DLSBot/$name", Toast.LENGTH_LONG).show()
            } else {
                val dir = getExternalFilesDir(null) ?: filesDir
                java.io.File(dir, name).writeText(text)
                Toast.makeText(this, "Saved ${dir.path}/$name", Toast.LENGTH_LONG).show()
            }
            Log.events.info(Category.SYSTEM, "log exported", "file" to name)
        } catch (e: Exception) {
            Log.events.error(Category.SYSTEM, "log export failed: ${e.message}")
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
