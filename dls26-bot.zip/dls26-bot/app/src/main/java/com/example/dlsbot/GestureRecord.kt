package com.example.dlsbot

/** Outcome of one dispatched gesture, as reported by Android (never guessed). */
enum class GestureResult { PENDING, COMPLETED, CANCELLED, REJECTED, DRY_RUN, BLOCKED, NO_SERVICE }

data class StrokeInfo(
    val kind: String,          // "tap" | "drag"
    val role: String,          // "stick" | "button" | "tap"
    val x1: Float, val y1: Float,
    val x2: Float, val y2: Float,
    val durationMs: Long
) {
    fun describe(): String =
        if (kind == "tap") String.format("%s tap (%.0f,%.0f) %dms", role, x1, y1, durationMs)
        else String.format("%s drag (%.0f,%.0f)->(%.0f,%.0f) %dms", role, x1, y1, x2, y2, durationMs)
}

data class GestureRecord(
    val id: Long,
    val strokes: List<StrokeInfo>,
    val result: GestureResult,
    val startedMs: Long,
    val finishedMs: Long
)

/**
 * Tracks what is known about the virtual-stick touch. "Touching" is derived only from dispatch
 * and the completion callback: between dispatch and callback a stick stroke is in flight; otherwise there is none.
 * It is NOT read back from the game, so it says nothing about whether the game accepted the touch.
 */
class ContactTracker {
    @Volatile var stickInFlight = false
        private set
    @Volatile var stickTouchesSent = 0L
        private set
    @Volatile var stickReleases = 0L
        private set

    @Synchronized fun onDispatch(strokes: List<StrokeInfo>) {
        if (strokes.any { it.role == "stick" }) {
            stickInFlight = true
            stickTouchesSent++
        }
    }

    @Synchronized fun onFinished(strokes: List<StrokeInfo>) {
        if (strokes.any { it.role == "stick" }) {
            stickInFlight = false
            stickReleases++
        }
    }
}

/** Keeps the latest gesture plus simple counters, for the dashboard. */
class GestureStats {
    @Volatile var last: GestureRecord? = null
    private val counts = HashMap<GestureResult, Long>()
    @Volatile var nextId = 0L
        private set

    @Synchronized fun newId(): Long = ++nextId

    @Synchronized fun record(r: GestureRecord) {
        last = r
        counts[r.result] = (counts[r.result] ?: 0L) + 1
    }

    @Synchronized fun count(r: GestureResult): Long = counts[r] ?: 0L
}
