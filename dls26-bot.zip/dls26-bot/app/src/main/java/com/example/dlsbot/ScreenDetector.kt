package com.example.dlsbot

import android.content.Context
import android.graphics.BitmapFactory
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.imgproc.Imgproc

/**
 * Recognises which DLS screen is showing, by template matching against PNGs in assets/templates.
 *
 * File naming:
 *  - `<SCREEN>__<label>.png`  identifies a screen, e.g. `RESULT__full_time_banner.png`
 *    (SCREEN is one of MENU, PRE_MATCH, IN_MATCH, HALF_TIME, RESULT, ERROR)
 *  - `BTN__<label>.png`       a tappable button, e.g. `BTN__continue.png`
 *
 * Templates must be cropped from screenshots resized to Config.CAPTURE_WIDTH pixels wide (landscape).
 */
class ScreenDetector(context: Context) {

    private val screenTemplates = mutableListOf<Pair<Screen, Mat>>()
    private val buttonTemplates = mutableMapOf<String, Mat>()

    init {
        val assets = context.assets
        assets.list("templates")?.filter { it.endsWith(".png") }?.forEach { file ->
            val bmp = assets.open("templates/$file").use { BitmapFactory.decodeStream(it) }
                ?: return@forEach
            val rgba = Mat()
            Utils.bitmapToMat(bmp, rgba)
            val gray = Mat()
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            rgba.release()

            val base = file.removeSuffix(".png")
            val prefix = base.substringBefore("__")
            val label = base.substringAfter("__", "")
            if (prefix == "BTN") {
                buttonTemplates[label] = gray
            } else {
                val screen = runCatching { Screen.valueOf(prefix) }.getOrNull()
                if (screen != null) screenTemplates += screen to gray else gray.release()
            }
        }
    }

    private fun gray(rgba: Mat): Mat {
        val g = Mat()
        Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
        return g
    }

    private fun match(frameGray: Mat, tpl: Mat): Pair<Double, Point>? {
        if (tpl.cols() > frameGray.cols() || tpl.rows() > frameGray.rows()) return null
        val res = Mat()
        Imgproc.matchTemplate(frameGray, tpl, res, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(res)
        res.release()
        return mm.maxVal to Point(mm.maxLoc.x + tpl.cols() / 2.0, mm.maxLoc.y + tpl.rows() / 2.0)
    }

    fun classify(rgba: Mat): Screen {
        val g = gray(rgba)
        var best = Screen.UNKNOWN
        var bestScore = Config.MATCH_THRESHOLD
        var inMatchSeen = false
        for ((screen, tpl) in screenTemplates) {
            val m = match(g, tpl) ?: continue
            if (m.first <= Config.MATCH_THRESHOLD) continue
            if (screen == Screen.IN_MATCH) {
                inMatchSeen = true
            } else if (m.first > bestScore) {
                // Overlays win: the pause button is still visible during a replay or the pause menu.
                bestScore = m.first
                best = screen
            }
        }
        g.release()

        if (best != Screen.UNKNOWN) return best
        if (inMatchSeen) return Screen.IN_MATCH

        // Fallback while no IN_MATCH templates exist: lots of grass means a match is on.
        if (screenTemplates.none { it.first == Screen.IN_MATCH } && PitchVision.coverage(rgba) > 0.4) {
            return Screen.IN_MATCH
        }
        return Screen.UNKNOWN
    }

    /** Centre of the named button template if it is on screen, else null. */
    fun find(rgba: Mat, label: String): Point? {
        val tpl = buttonTemplates[label] ?: return null
        val g = gray(rgba)
        val m = match(g, tpl)
        g.release()
        return if (m != null && m.first > Config.MATCH_THRESHOLD) m.second else null
    }

    fun templateSummary(): String =
        "${screenTemplates.size} screen templates, ${buttonTemplates.size} button templates"
}
