package com.example.dlsbot

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.PointF
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * Recognises which DLS screen is showing, by template matching against the PNGs in assets/templates
 * (all cut from real DLS 26 screenshots at 640 px wide), and tells attacking from defending by the
 * labels on the B and C buttons.
 */
class ScreenDetector(context: Context) {

    private val tpl = HashMap<String, Mat>()
    private val labelTpl = HashMap<String, Mat>() // high-passed, top half only

    init {
        val opts = BitmapFactory.Options()
        opts.inScaled = false
        for (name in Config.TEMPLATES) {
            val bmp = try {
                context.assets.open("templates/$name.png").use { BitmapFactory.decodeStream(it, null, opts) }
            } catch (e: Exception) {
                null
            } ?: continue
            val rgba = Mat()
            Utils.bitmapToMat(bmp, rgba)
            val g = Mat()
            Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
            rgba.release()
            if (name.startsWith("att_") || name.startsWith("def_")) {
                val hp = highPass(g)
                g.release()
                val top = hp.submat(Rect(0, 0, hp.cols(), (hp.rows() * 0.52).toInt()))
                labelTpl[name] = top.clone()
                top.release()
                hp.release()
            } else {
                tpl[name] = g
            }
        }
    }

    private fun highPass(src: Mat): Mat {
        val f = Mat()
        src.convertTo(f, CvType.CV_32F)
        val blur = Mat()
        Imgproc.GaussianBlur(f, blur, Size(0.0, 0.0), 2.5)
        val out = Mat()
        Core.subtract(f, blur, out)
        f.release()
        blur.release()
        return out
    }

    /** Best match (score, centre in frame px) of a template inside its search area, or null. */
    private fun locate(gray: Mat, name: String): Pair<Double, Point>? {
        val t = tpl[name] ?: return null
        val w = gray.cols()
        val h = gray.rows()
        val roi = Config.ROI[name]
        val x0 = if (roi != null) (roi.l * w).toInt().coerceIn(0, w - 1) else 0
        val y0 = if (roi != null) (roi.t * h).toInt().coerceIn(0, h - 1) else 0
        val x1 = if (roi != null) (roi.r * w).toInt().coerceIn(1, w) else w
        val y1 = if (roi != null) (roi.b * h).toInt().coerceIn(1, h) else h
        if (x1 - x0 < t.cols() || y1 - y0 < t.rows()) return null
        val sub = gray.submat(Rect(x0, y0, x1 - x0, y1 - y0))
        val res = Mat()
        Imgproc.matchTemplate(sub, t, res, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(res)
        res.release()
        sub.release()
        val v = if (mm.maxVal.isNaN()) 0.0 else mm.maxVal
        return Pair(v, Point(x0 + mm.maxLoc.x + t.cols() / 2.0, y0 + mm.maxLoc.y + t.rows() / 2.0))
    }

    fun score(gray: Mat, name: String): Double = locate(gray, name)?.first ?: 0.0

    fun has(gray: Mat, name: String): Boolean = score(gray, name) >= Config.threshold(name)

    /** Centre (frame px) of the template if it is on screen, else null. */
    fun find(gray: Mat, name: String): Point? {
        val r = locate(gray, name) ?: return null
        return if (r.first >= Config.threshold(name)) r.second else null
    }

    fun classify(gray: Mat): Screen {
        if (has(gray, "resume")) return Screen.PAUSED
        if (has(gray, "continue")) return Screen.RESULT
        if (has(gray, "lineup_play") && has(gray, "lineup_team")) return Screen.LINEUP
        if (has(gray, "home_tag")) return Screen.HOME
        if (has(gray, "tap_to_skip") || has(gray, "subs_banner")) return Screen.CUTSCENE
        if (has(gray, "pause")) {
            // The black loading screen after full time still shows a faint pause button: not a match.
            if (Core.mean(gray).`val`[0] < 40.0) return Screen.UNKNOWN
            return Screen.IN_MATCH
        }
        return Screen.UNKNOWN
    }

    private fun labelScore(gray: Mat, btn: String, c: PointF, state: String): Double {
        val t = labelTpl["${state}_$btn"] ?: return 0.0
        val w = gray.cols()
        val h = gray.rows()
        val cx = (c.x * w).toInt()
        val cy = (c.y * h).toInt()
        val m = 28
        val x0 = (cx - m).coerceAtLeast(0)
        val y0 = (cy - m).coerceAtLeast(0)
        val x1 = (cx + m).coerceAtMost(w)
        val y1 = (cy + m).coerceAtMost(h)
        if (x1 - x0 < t.cols() || y1 - y0 < t.rows()) return 0.0
        val win = gray.submat(Rect(x0, y0, x1 - x0, y1 - y0))
        val hp = highPass(win)
        win.release()
        val res = Mat()
        Imgproc.matchTemplate(hp, t, res, Imgproc.TM_CCOEFF_NORMED)
        val v = Core.minMaxLoc(res).maxVal
        res.release()
        hp.release()
        return if (v.isNaN()) 0.0 else v
    }

    /**
     * True when the B and C buttons read LOW KICK / LOFTED KICK (your team has the ball),
     * false when they read PRESSURE / SWITCH PLAYER (the other team has it).
     * Tested on real screenshots: perfect separation (attack >= +0.16, defend <= -0.2).
     */
    fun isAttacking(gray: Mat): Boolean {
        val att = labelScore(gray, "B", Config.BTN_B, "att") + labelScore(gray, "C", Config.BTN_C, "att")
        val def = labelScore(gray, "B", Config.BTN_B, "def") + labelScore(gray, "C", Config.BTN_C, "def")
        return att >= def
    }

    /** One line per template with its current score: for checking that matching works on your phone. */
    fun debugScores(gray: Mat): String {
        val sb = StringBuilder()
        for (name in Config.TEMPLATES) {
            if (name.startsWith("att_") || name.startsWith("def_")) continue
            val s = score(gray, name)
            sb.append(name).append(": ").append(String.format("%.2f", s))
            if (s >= Config.threshold(name)) sb.append("  MATCH")
            sb.append('\n')
        }
        sb.append("attacking labels: ").append(isAttacking(gray)).append('\n')
        return sb.toString()
    }

    fun templateSummary(): String = "${tpl.size + labelTpl.size / 2} of ${Config.TEMPLATES.size - 2} templates loaded"
}
