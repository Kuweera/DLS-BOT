# Changelog

## 0.2-phase1 (candidate, NOT yet run on a phone)
Last known-good: v1.0 (dls26-bot-v1.0-lastgood.zip; it built and ran on the owner's phone, play quality poor).
Added (no gameplay logic changed):
- EventLog.kt: structured event log (VISION/TRACK/DECISION/CONTROL/OUTCOME/SYSTEM), ring buffer of 1000, JSON-lines export.
- RunControl.kt: STOPPED/RUNNING/PAUSED/EMERGENCY + dry-run flag + one gate decision (SEND / DRY_RUN / BLOCKED).
- GestureRecord.kt: gesture records (strokes, coordinates, duration, result), stick-contact tracker (derived from dispatch/callback only).
- Gestures.kt: every tap/drag/back now goes through one dispatch() that applies the gate and logs what was sent and what Android reported. Stroke geometry is identical to v1.0.
- GestureService.perform now returns COMPLETED / CANCELLED / REJECTED instead of a Boolean.
- FrameStore: published-frame counter and timestamp. BotController: classify time, loop time, processed/skipped frames, pause/resume/emergencyStop, DECISION log on status change, VISION log on screen change.
- DebugDashboard.kt (opened from the main screen): run controls, dry-run, capture/frame age, vision, last gesture, stick contact, warnings, recent events, template scores (on demand), log export to Download/DLSBot.
Not changed: detection, templates, attack/defend logic, timers, joystick stroke shape, workflow file.
